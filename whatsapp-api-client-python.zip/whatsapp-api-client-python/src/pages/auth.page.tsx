import { FC } from 'react';

import AuthForm from 'components/forms/auth-form.component';

const Auth: FC = () => {
  return <AuthForm />;
};

export default Auth;
