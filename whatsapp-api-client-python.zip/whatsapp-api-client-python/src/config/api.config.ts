export const getBackendApiUrl = (): string => {
  if (typeof window !== 'undefined' && window.location.hostname.includes('replit.dev')) {
    const parts = window.location.hostname.split('.');
    if (parts.length >= 2) {
      const replId = parts[0];
      parts[0] = `${replId}-3000`;
      return `https://${parts.join('.')}`;
    }
  }
  
  return import.meta.env.VITE_API_URL || 'http://localhost:3000';
};

export const API_BASE_URL = getBackendApiUrl();
