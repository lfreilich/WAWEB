import { greenAPI } from 'services/green-api/green-api.service';
import {
  GetStateInstanceResponseInterface,
  GetWaSettingsResponseInterface,
  InstanceInterface,
} from 'types';

export const accountGreenApiEndpoints = greenAPI.injectEndpoints({
  endpoints: (builder) => ({
    getWaSettings: builder.query<
      GetWaSettingsResponseInterface,
      InstanceInterface & { rtkWaSettingsSessionKey?: number }
    >({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/getWaSettings/${apiTokenInstance}`,
      }),
      keepUnusedDataFor: 1000,
    }),
    getAccountSettings: builder.query<
      GetWaSettingsResponseInterface,
      InstanceInterface & { rtkWaSettingsSessionKey?: number }
    >({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/getAccountSettings/${apiTokenInstance}`,
      }),
      keepUnusedDataFor: 1000,
    }),
    setSettings: builder.mutation<
      any,
      InstanceInterface & { [key: string]: any }
    >({
      query: ({ idInstance, apiTokenInstance, apiUrl, mediaUrl: _, ...body }) => ({
        url: `${apiUrl}waInstance${idInstance}/setSettings/${apiTokenInstance}`,
        method: 'POST',
        body,
      }),
    }),
    getStateInstance: builder.query<GetStateInstanceResponseInterface, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/getStateInstance/${apiTokenInstance}`,
      }),
    }),
    getStatusInstance: builder.query<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/getStatusInstance/${apiTokenInstance}`,
      }),
    }),
    reboot: builder.mutation<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/reboot/${apiTokenInstance}`,
        method: 'GET',
      }),
    }),
    logout: builder.mutation<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/logout/${apiTokenInstance}`,
        method: 'GET',
      }),
    }),
    qr: builder.query<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/qr/${apiTokenInstance}`,
      }),
    }),
    setProfilePicture: builder.mutation<
      any,
      InstanceInterface & { file: File }
    >({
      query: ({ idInstance, apiTokenInstance, mediaUrl, file }) => ({
        url: `${mediaUrl}waInstance${idInstance}/setProfilePicture/${apiTokenInstance}`,
        method: 'POST',
        body: file,
      }),
    }),
    getAuthorizationCode: builder.mutation<
      any,
      InstanceInterface & { phoneNumber: string }
    >({
      query: ({ idInstance, apiTokenInstance, apiUrl, mediaUrl: _, ...body }) => ({
        url: `${apiUrl}waInstance${idInstance}/getAuthorizationCode/${apiTokenInstance}`,
        method: 'POST',
        body,
      }),
    }),
    getDeviceInfo: builder.query<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/getDeviceInfo/${apiTokenInstance}`,
      }),
    }),
    updateAPIToken: builder.mutation<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/updateAPIToken/${apiTokenInstance}`,
        method: 'GET',
      }),
    }),
    getWhatsAppAccountInformation: builder.query<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/getWhatsAppAccountInformation/${apiTokenInstance}`,
      }),
    }),
  }),
});
