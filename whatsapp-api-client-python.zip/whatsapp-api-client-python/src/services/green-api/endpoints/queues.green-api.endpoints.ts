import { greenAPI } from 'services/green-api/green-api.service';
import { InstanceInterface } from 'types';

export const queuesGreenApiEndpoints = greenAPI.injectEndpoints({
  endpoints: (builder) => ({
    showMessagesQueue: builder.query<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/showMessagesQueue/${apiTokenInstance}`,
      }),
    }),
    clearMessagesQueue: builder.mutation<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/clearMessagesQueue/${apiTokenInstance}`,
        method: 'GET',
      }),
    }),
    getMessagesCount: builder.query<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/getMessagesCount/${apiTokenInstance}`,
      }),
    }),
    getWebhooksCount: builder.query<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/getWebhooksCount/${apiTokenInstance}`,
      }),
    }),
    clearIncomingWebhooksQueue: builder.mutation<any, InstanceInterface>({
      query: ({ idInstance, apiTokenInstance, apiUrl }) => ({
        url: `${apiUrl}waInstance${idInstance}/clearIncomingWebhooksQueue/${apiTokenInstance}`,
        method: 'GET',
      }),
    }),
  }),
});
