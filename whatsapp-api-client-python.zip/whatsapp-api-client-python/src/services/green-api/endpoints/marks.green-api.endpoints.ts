import { greenAPI } from 'services/green-api/green-api.service';
import { InstanceInterface } from 'types';

export const marksGreenApiEndpoints = greenAPI.injectEndpoints({
  endpoints: (builder) => ({
    readChat: builder.mutation<
      any,
      InstanceInterface & { chatId: string; idMessage?: string }
    >({
      query: ({ idInstance, apiTokenInstance, apiUrl, mediaUrl: _, ...body }) => ({
        url: `${apiUrl}waInstance${idInstance}/readChat/${apiTokenInstance}`,
        method: 'POST',
        body,
      }),
    }),
    markMessageAsRead: builder.mutation<
      any,
      InstanceInterface & { chatId: string; idMessage: string }
    >({
      query: ({ idInstance, apiTokenInstance, apiUrl, mediaUrl: _, ...body }) => ({
        url: `${apiUrl}waInstance${idInstance}/markMessageAsRead/${apiTokenInstance}`,
        method: 'POST',
        body,
      }),
    }),
  }),
});
