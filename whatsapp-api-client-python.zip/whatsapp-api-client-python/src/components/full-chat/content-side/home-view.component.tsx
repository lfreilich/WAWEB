import { FC } from 'react';

import { Flex, Typography } from 'antd';
import { LockOutlined } from '@ant-design/icons';

const HomeView: FC = () => {
  return (
    <Flex className="home-view whatsapp-home" align="center" justify="center" vertical>
      <div className="whatsapp-empty-state">
        <div className="empty-icon">
          <svg viewBox="0 0 303 172" width="360" preserveAspectRatio="xMidYMid meet">
            <path fill="#DFE5E7" d="M170.5 55.3a3.7 3.7 0 11-7.4 0 3.7 3.7 0 017.4 0zm36.2-9.5c0 1.5-1 2.7-2.2 2.7s-2.2-1.2-2.2-2.7 1-2.6 2.2-2.6 2.2 1.2 2.2 2.6z"></path>
            <path fill="#DFE5E7" d="M64.8 148.7h173.8c11.9 0 21.6-9.7 21.6-21.6V40.9c0-11.9-9.7-21.6-21.6-21.6H64.8c-11.9 0-21.6 9.7-21.6 21.6v86.2c0 11.9 9.7 21.6 21.6 21.6z"></path>
            <path fill="#FFF" d="M64.8 22.8h173.8c10 0 18.1 8.1 18.1 18.1v86.2c0 10-8.1 18.1-18.1 18.1H64.8c-10 0-18.1-8.1-18.1-18.1V40.9c0-10 8.1-18.1 18.1-18.1z"></path>
          </svg>
        </div>
        <Typography.Title level={3} style={{ color: '#41525d', fontWeight: 300, marginTop: 28, marginBottom: 10 }}>
          Bialle Chat
        </Typography.Title>
        <Typography.Text style={{ fontSize: 14, color: '#667781', textAlign: 'center', maxWidth: 360, display: 'block', lineHeight: 1.5 }}>
          Keeping the Community Connected
        </Typography.Text>
        <div style={{ marginTop: 40, padding: '10px 20px', backgroundColor: '#fef5e4', borderRadius: 8, maxWidth: 450, display: 'flex', alignItems: 'center', gap: 10 }}>
          <LockOutlined style={{ color: '#51585c', fontSize: 20 }} />
          <Typography.Text style={{ fontSize: 13, color: '#54656f' }}>
            Your personal messages are end-to-end encrypted
          </Typography.Text>
        </div>
      </div>
    </Flex>
  );
};

export default HomeView;
