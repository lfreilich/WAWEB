import { FC, useState } from 'react';

import { CloseOutlined, LeftOutlined, DeleteOutlined, InboxOutlined } from '@ant-design/icons';
import { Space, Dropdown, Modal, message as antMessage } from 'antd';
import { Header } from 'antd/es/layout/layout';

import waChatIcon from 'assets/wa-chat.svg';
import AvatarImage from 'components/UI/avatar-image.component';
import { useActions, useAppSelector } from 'hooks';
import { selectActiveChat, selectType } from 'store/slices/chat.slice';
import { selectInstance } from 'store/slices/instances.slice';
import { ActiveChat } from 'types';
import { isWhatsAppOfficialChat } from 'utils';
import { useArchiveChatMutation, useUnarchiveChatMutation } from 'services/green-api/endpoints';

const ContactChatHeader: FC = () => {
  const activeChat = useAppSelector(selectActiveChat) as ActiveChat;
  const type = useAppSelector(selectType);
  const instance = useAppSelector(selectInstance);

  const { setActiveChat, setContactInfoOpen } = useActions();
  const [archiveChat] = useArchiveChatMutation();
  const [unarchiveChat] = useUnarchiveChatMutation();

  const [clearModalVisible, setClearModalVisible] = useState(false);

  const isOfficial = isWhatsAppOfficialChat(activeChat.chatId);

  const handleArchive = async () => {
    try {
      await archiveChat({ ...instance, chatId: activeChat.chatId }).unwrap();
      antMessage.success('Chat archived successfully');
      setActiveChat(null);
    } catch (error) {
      antMessage.error('Failed to archive chat');
    }
  };

  const handleUnarchive = async () => {
    try {
      await unarchiveChat({ ...instance, chatId: activeChat.chatId }).unwrap();
      antMessage.success('Chat unarchived successfully');
    } catch (error) {
      antMessage.error('Failed to unarchive chat');
    }
  };

  const handleClearMessages = async () => {
    try {
      const response = await fetch(`/api/messages/${activeChat.chatId}`, {
        method: 'DELETE',
      });
      
      if (response.ok) {
        antMessage.success('All messages cleared from this chat');
        setClearModalVisible(false);
        window.location.reload();
      } else {
        antMessage.error('Failed to clear messages');
      }
    } catch (error) {
      antMessage.error('Failed to clear messages');
    }
  };

  const menuItems = [
    {
      key: 'archive',
      icon: <InboxOutlined />,
      label: 'Archive Chat',
      onClick: handleArchive,
    },
    {
      key: 'unarchive',
      icon: <InboxOutlined />,
      label: 'Unarchive Chat',
      onClick: handleUnarchive,
    },
    {
      key: 'clear',
      icon: <DeleteOutlined />,
      label: 'Clear All Messages',
      onClick: () => setClearModalVisible(true),
      danger: true,
    },
  ];

  return (
    <>
      <Header className="contact-chat-header">
        <Space className="chatHeader-space">
          <LeftOutlined 
            className="mobile-back-button"
            style={{ 
              fontSize: 20, 
              cursor: 'pointer',
              color: '#54656f',
              marginRight: 8
            }} 
            onClick={() => setActiveChat(null)} 
          />
          <div onClick={() => setContactInfoOpen(true)} style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}>
            <AvatarImage src={isOfficial ? waChatIcon : activeChat.avatar} size="large" />
            <h3 className="text-overflow">{isOfficial ? 'WhatsApp' : activeChat.senderName}</h3>
          </div>
        </Space>

        <Space size={20}>
          {!isOfficial && (
            <Dropdown menu={{ items: menuItems }} trigger={['click']} placement="bottomRight">
              <span
                style={{ 
                  fontSize: 14, 
                  cursor: 'pointer', 
                  color: '#54656f',
                  padding: '8px 12px',
                  fontWeight: 500,
                  whiteSpace: 'nowrap'
                }} 
              >
                More Options
              </span>
            </Dropdown>
          )}
          {type !== 'one-chat-only' && (
            <CloseOutlined 
              style={{ 
                fontSize: 20, 
                cursor: 'pointer',
                color: '#54656f',
                padding: '4px'
              }} 
              onClick={() => setActiveChat(null)} 
            />
          )}
        </Space>
      </Header>

      <Modal
        title="Clear All Messages"
        open={clearModalVisible}
        onOk={handleClearMessages}
        onCancel={() => setClearModalVisible(false)}
        okText="Clear All"
        okButtonProps={{ danger: true }}
      >
        <p>Are you sure you want to clear all messages from this chat?</p>
        <p><strong>This action cannot be undone.</strong></p>
      </Modal>
    </>
  );
};

export default ContactChatHeader;
