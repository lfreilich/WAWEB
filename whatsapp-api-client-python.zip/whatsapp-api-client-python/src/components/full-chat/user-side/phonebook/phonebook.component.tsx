import { FC, useEffect, useState } from 'react';
import { Button, Input, List, Modal, Form, Spin, Switch, message } from 'antd';
import {
  UserAddOutlined,
  EditOutlined,
  DeleteOutlined,
  StarOutlined,
  StarFilled,
  SearchOutlined,
  SyncOutlined,
} from '@ant-design/icons';
import './phonebook.styles.scss';
import { API_BASE_URL } from 'config/api.config';

const { TextArea } = Input;

interface Contact {
  id: number;
  chat_id: string;
  name: string;
  phone_number?: string;
  avatar_url?: string;
  notes?: string;
  is_favorite: boolean;
  created_at: string;
  updated_at: string;
}

const Phonebook: FC = () => {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [filteredContacts, setFilteredContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [syncing, setSyncing] = useState(false);
  const [form] = Form.useForm();

  const syncFromWhatsApp = async () => {
    try {
      setSyncing(true);
      
      const response = await fetch(`${API_BASE_URL}/api/sync/contacts`);
      
      if (!response.ok) {
        throw new Error('Failed to sync contacts');
      }

      const result = await response.json();
      
      if (result.count === 0) {
        message.info('No new contacts found');
      } else {
        message.success(`Synced ${result.count} contacts from WhatsApp`);
      }
      
      fetchContacts();
    } catch (error) {
      console.error('Error syncing contacts:', error);
      message.error('Failed to sync contacts from WhatsApp');
    } finally {
      setSyncing(false);
    }
  };

  const fetchContacts = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_BASE_URL}/api/contacts`);
      const data = await response.json();
      setContacts(data);
      setFilteredContacts(data);
    } catch (error) {
      console.error('Error fetching contacts:', error);
      message.error('Failed to load contacts');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContacts();
  }, []);

  useEffect(() => {
    if (searchQuery) {
      const filtered = contacts.filter(
        (contact) =>
          contact.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          contact.phone_number?.includes(searchQuery) ||
          contact.notes?.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredContacts(filtered);
    } else {
      setFilteredContacts(contacts);
    }
  }, [searchQuery, contacts]);

  const handleAddOrEdit = async (values: any) => {
    try {
      setLoading(true);
      const url = editingContact
        ? `${API_BASE_URL}/api/contacts/${editingContact.chat_id}`
        : `${API_BASE_URL}/api/contacts`;
      const method = editingContact ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });

      if (response.ok) {
        message.success(editingContact ? 'Contact updated' : 'Contact added');
        setIsModalVisible(false);
        form.resetFields();
        setEditingContact(null);
        fetchContacts();
      } else {
        message.error('Failed to save contact');
      }
    } catch (error) {
      console.error('Error saving contact:', error);
      message.error('Failed to save contact');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (chatId: string) => {
    try {
      setLoading(true);
      const response = await fetch(`${API_BASE_URL}/api/contacts/${chatId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        message.success('Contact deleted');
        fetchContacts();
      } else {
        message.error('Failed to delete contact');
      }
    } catch (error) {
      console.error('Error deleting contact:', error);
      message.error('Failed to delete contact');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (contact: Contact) => {
    setEditingContact(contact);
    form.setFieldsValue(contact);
    setIsModalVisible(true);
  };

  const handleToggleFavorite = async (contact: Contact) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/contacts/${contact.chat_id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...contact,
          is_favorite: !contact.is_favorite,
        }),
      });

      if (response.ok) {
        fetchContacts();
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  const favorites = filteredContacts.filter((c) => c.is_favorite);
  const regularContacts = filteredContacts.filter((c) => !c.is_favorite);

  return (
    <div className="phonebook-container">
      <div className="phonebook-header">
        <h2>Phonebook</h2>
        <div style={{ display: 'flex', gap: '8px' }}>
          <Button
            icon={<SyncOutlined spin={syncing} />}
            onClick={syncFromWhatsApp}
            loading={syncing}
          >
            Sync from WhatsApp
          </Button>
          <Button
            type="primary"
            icon={<UserAddOutlined />}
            onClick={() => {
              setEditingContact(null);
              form.resetFields();
              setIsModalVisible(true);
            }}
          >
            Add Contact
          </Button>
        </div>
      </div>

      <div className="phonebook-search">
        <Input
          placeholder="Search contacts..."
          prefix={<SearchOutlined />}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          size="large"
        />
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px' }}>
          <Spin size="large" />
        </div>
      ) : (
        <>
          {favorites.length > 0 && (
            <div className="contact-section">
              <h3>
                <StarFilled style={{ color: '#faad14' }} /> Favorites
              </h3>
              <List
                dataSource={favorites}
                renderItem={(contact) => (
                  <List.Item
                    actions={[
                      <Button
                        key="favorite"
                        type="text"
                        icon={<StarFilled style={{ color: '#faad14' }} />}
                        onClick={() => handleToggleFavorite(contact)}
                      />,
                      <Button
                        key="edit"
                        type="text"
                        icon={<EditOutlined />}
                        onClick={() => handleEdit(contact)}
                      />,
                      <Button
                        key="delete"
                        type="text"
                        danger
                        icon={<DeleteOutlined />}
                        onClick={() => handleDelete(contact.chat_id)}
                      />,
                    ]}
                  >
                    <List.Item.Meta
                      title={contact.name || contact.chat_id}
                      description={
                        <>
                          {contact.phone_number && <div>{contact.phone_number}</div>}
                          {contact.notes && (
                            <div style={{ color: '#8c8c8c', fontSize: '12px' }}>
                              {contact.notes}
                            </div>
                          )}
                        </>
                      }
                    />
                  </List.Item>
                )}
              />
            </div>
          )}

          <div className="contact-section">
            {favorites.length > 0 && <h3>All Contacts</h3>}
            <List
              dataSource={regularContacts}
              renderItem={(contact) => (
                <List.Item
                  actions={[
                    <Button
                      key="favorite"
                      type="text"
                      icon={<StarOutlined />}
                      onClick={() => handleToggleFavorite(contact)}
                    />,
                    <Button
                      key="edit"
                      type="text"
                      icon={<EditOutlined />}
                      onClick={() => handleEdit(contact)}
                    />,
                    <Button
                      key="delete"
                      type="text"
                      danger
                      icon={<DeleteOutlined />}
                      onClick={() => handleDelete(contact.chat_id)}
                    />,
                  ]}
                >
                  <List.Item.Meta
                    title={contact.name || contact.chat_id}
                    description={
                      <>
                        {contact.phone_number && <div>{contact.phone_number}</div>}
                        {contact.notes && (
                          <div style={{ color: '#8c8c8c', fontSize: '12px' }}>{contact.notes}</div>
                        )}
                      </>
                    }
                  />
                </List.Item>
              )}
            />
          </div>
        </>
      )}

      <Modal
        title={editingContact ? 'Edit Contact' : 'Add Contact'}
        open={isModalVisible}
        onCancel={() => {
          setIsModalVisible(false);
          setEditingContact(null);
          form.resetFields();
        }}
        footer={null}
      >
        <Form form={form} onFinish={handleAddOrEdit} layout="vertical">
          <Form.Item
            name="chat_id"
            label="Chat ID (WhatsApp number with country code)"
            rules={[{ required: true, message: 'Please enter chat ID' }]}
          >
            <Input placeholder="79001234567@c.us" disabled={!!editingContact} />
          </Form.Item>
          <Form.Item name="name" label="Name" rules={[{ required: true }]}>
            <Input placeholder="John Doe" />
          </Form.Item>
          <Form.Item name="phone_number" label="Phone Number">
            <Input placeholder="+1 234 567 8900" />
          </Form.Item>
          <Form.Item name="notes" label="Notes">
            <TextArea placeholder="Add notes about this contact..." />
          </Form.Item>
          <Form.Item name="is_favorite" label="Favorite" valuePropName="checked">
            <Switch />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" loading={loading} block>
              {editingContact ? 'Update' : 'Add'} Contact
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default Phonebook;
