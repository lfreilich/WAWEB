import { FC, useState } from 'react';

import { LogoutOutlined, UserAddOutlined, MessageOutlined, EllipsisOutlined, SyncOutlined } from '@ant-design/icons';
import { Flex, Avatar, message } from 'antd';
import { Header } from 'antd/es/layout/layout';
import { useTranslation } from 'react-i18next';

import AddNewChat from './add-new-chat.component';
import { useActions } from 'hooks';
import { TariffsEnum } from 'types';
import { API_BASE_URL } from 'config/api.config';

const ChatsHeader: FC = () => {
  const { t, i18n } = useTranslation();
  const { logout, setActiveChat, setSelectedInstance } = useActions();

  const [isVisible, setIsVisible] = useState(false);
  const [syncing, setSyncing] = useState(false);

  const dir = i18n.dir();

  const syncChatsFromWhatsApp = async () => {
    try {
      setSyncing(true);
      const response = await fetch(`${API_BASE_URL}/api/sync/chats`);
      
      if (!response.ok) {
        throw new Error('Failed to sync chats');
      }

      const result = await response.json();
      message.success(`Synced ${result.count} chats from WhatsApp`);
      window.location.reload();
    } catch (error) {
      console.error('Error syncing chats:', error);
      message.error('Failed to sync chats from WhatsApp');
    } finally {
      setSyncing(false);
    }
  };

  const onLogoutClick = () => {
    setActiveChat(null);
    setSelectedInstance({
      idInstance: 0,
      apiTokenInstance: '',
      apiUrl: '',
      mediaUrl: '',
      typeInstance: 'whatsapp',
      tariff: TariffsEnum.Developer,
    });
    logout();
  };

  return (
    <Header className="whatsapp-header" style={{ padding: '10px 16px', height: 60, display: 'flex', alignItems: 'center' }}>
      <Flex justify="space-between" align="center" style={{ width: '100%' }}>
        <Avatar size={40} style={{ backgroundColor: '#0a6e5c', color: '#ffffff' }}>
          <MessageOutlined style={{ fontSize: 22, color: '#ffffff' }} />
        </Avatar>
        <Flex align="center" justify="center" gap={20}>
          <SyncOutlined
            spin={syncing}
            style={{ fontSize: 22, color: '#ffffff', cursor: 'pointer' }}
            onClick={syncChatsFromWhatsApp}
            title="Sync Chats from WhatsApp"
          />
          <UserAddOutlined
            style={{ fontSize: 22, color: '#ffffff', cursor: 'pointer' }}
            onClick={() => setIsVisible(true)}
            title={t('ADD_NEW_CHAT_HEADER')}
          />
          <EllipsisOutlined
            style={{ fontSize: 22, color: '#ffffff', cursor: 'pointer' }}
            title="Menu"
          />
          <LogoutOutlined
            style={{ fontSize: 22, color: '#ffffff', cursor: 'pointer', transform: dir === 'rtl' ? 'rotateY(180deg)' : 'unset' }}
            onClick={onLogoutClick}
            title={t('LOGOUT')}
          />
        </Flex>
      </Flex>
      <AddNewChat isVisible={isVisible} setIsVisible={setIsVisible} />
    </Header>
  );
};

export default ChatsHeader;
