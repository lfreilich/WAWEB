import { FC } from 'react';
import { Button, Card, Space, message } from 'antd';
import { useAppSelector } from 'hooks';
import { selectInstance } from 'store/slices/instances.slice';
import {
  useRebootMutation,
  useLogoutMutation,
  useGetAccountSettingsQuery,
  useGetStatusInstanceQuery,
  useGetDeviceInfoQuery,
} from 'services/green-api/endpoints';

const AccountTools: FC = () => {
  const instance = useAppSelector(selectInstance);
  const [reboot, { isLoading: isRebooting }] = useRebootMutation();
  const [logout, { isLoading: isLoggingOut }] = useLogoutMutation();

  const { data: accountSettings, refetch: refetchSettings } = useGetAccountSettingsQuery(instance);
  const { data: statusInstance, refetch: refetchStatus } = useGetStatusInstanceQuery(instance);
  const { data: deviceInfo, refetch: refetchDevice } = useGetDeviceInfoQuery(instance);

  const handleReboot = async () => {
    try {
      await reboot(instance).unwrap();
      message.success('Instance rebooted successfully');
    } catch (error) {
      message.error('Failed to reboot instance');
    }
  };

  const handleLogout = async () => {
    try {
      await logout(instance).unwrap();
      message.success('Logged out successfully');
    } catch (error) {
      message.error('Failed to logout');
    }
  };

  return (
    <div className="tool-section">
      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
        <Card title="Instance Actions" size="small">
          <Space>
            <Button loading={isRebooting} onClick={handleReboot}>
              Reboot Instance
            </Button>
            <Button danger loading={isLoggingOut} onClick={handleLogout}>
              Logout Instance
            </Button>
          </Space>
        </Card>

        <Card title="Account Settings" size="small">
          <Button onClick={() => refetchSettings()}>Get Account Settings</Button>
          {accountSettings && (
            <pre style={{ marginTop: 10, fontSize: 12 }}>
              {JSON.stringify(accountSettings, null, 2)}
            </pre>
          )}
        </Card>

        <Card title="Instance Status" size="small">
          <Button onClick={() => refetchStatus()}>Get Status</Button>
          {statusInstance && (
            <pre style={{ marginTop: 10, fontSize: 12 }}>
              {JSON.stringify(statusInstance, null, 2)}
            </pre>
          )}
        </Card>

        <Card title="Device Info" size="small">
          <Button onClick={() => refetchDevice()}>Get Device Info</Button>
          {deviceInfo && (
            <pre style={{ marginTop: 10, fontSize: 12 }}>{JSON.stringify(deviceInfo, null, 2)}</pre>
          )}
        </Card>
      </Space>
    </div>
  );
};

export default AccountTools;
