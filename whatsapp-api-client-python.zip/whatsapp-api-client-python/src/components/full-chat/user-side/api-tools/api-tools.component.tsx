import { FC, useState } from 'react';
import { Button, Card, Input, Space, Avatar, Divider, Collapse } from 'antd';
import {
  ApiOutlined,
  SendOutlined,
  TeamOutlined,
  ToolOutlined,
  HistoryOutlined,
  StarOutlined,
  UnorderedListOutlined,
  CheckOutlined,
  RobotOutlined,
  SettingOutlined,
} from '@ant-design/icons';
import './api-tools.styles.scss';

const { Panel } = Collapse;

const APITools: FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const apiCategories = [
    {
      key: 'account',
      icon: <SettingOutlined />,
      title: 'Account Management',
      description: 'Manage instance settings, reboot, logout, QR code',
      color: '#1890ff',
    },
    {
      key: 'sending',
      icon: <SendOutlined />,
      title: 'Send Messages',
      description: 'Send files, links, contacts, locations, polls',
      color: '#52c41a',
    },
    {
      key: 'groups',
      icon: <TeamOutlined />,
      title: 'Group Management',
      description: 'Create groups, manage participants, settings',
      color: '#722ed1',
    },
    {
      key: 'service',
      icon: <ToolOutlined />,
      title: 'Service Methods',
      description: 'Check WhatsApp, archive chats, typing indicators',
      color: '#fa8c16',
    },
    {
      key: 'journals',
      icon: <HistoryOutlined />,
      title: 'Message History',
      description: 'Get chat history, recent messages',
      color: '#13c2c2',
    },
    {
      key: 'statuses',
      icon: <StarOutlined />,
      title: 'Status Updates',
      description: 'View and manage WhatsApp statuses',
      color: '#eb2f96',
    },
    {
      key: 'queues',
      icon: <UnorderedListOutlined />,
      title: 'Message Queues',
      description: 'View and clear message queues',
      color: '#faad14',
    },
    {
      key: 'marks',
      icon: <CheckOutlined />,
      title: 'Read Marks',
      description: 'Mark chats as read',
      color: '#2db7f5',
    },
  ];

  return (
    <div className="api-tools-whatsapp">
      <div className="api-tools-chat-header">
        <Avatar size={40} style={{ backgroundColor: '#25D366' }} icon={<RobotOutlined />} />
        <div className="header-info">
          <div className="header-name">WhatsApp API Assistant</div>
          <div className="header-status">Access all WhatsApp API methods</div>
        </div>
      </div>

      <div className="api-tools-chat-body">
        <div className="message-bubble incoming">
          <div className="bubble-content">
            <strong>👋 Welcome to API Tools!</strong>
            <p style={{ marginTop: 8, marginBottom: 0 }}>
              Choose a category below to access WhatsApp API methods. Each category contains
              powerful tools for managing your WhatsApp instance.
            </p>
          </div>
          <div className="bubble-time">Just now</div>
        </div>

        <div className="api-categories-grid">
          {apiCategories.map((category) => (
            <Card
              key={category.key}
              className="api-category-card"
              hoverable
              onClick={() => setSelectedCategory(category.key)}
            >
              <div className="category-icon" style={{ color: category.color }}>
                {category.icon}
              </div>
              <div className="category-title">{category.title}</div>
              <div className="category-description">{category.description}</div>
            </Card>
          ))}
        </div>

        {selectedCategory && (
          <div className="message-bubble incoming">
            <div className="bubble-content">
              <div style={{ marginBottom: 12 }}>
                <strong>
                  {apiCategories.find((c) => c.key === selectedCategory)?.icon}{' '}
                  {apiCategories.find((c) => c.key === selectedCategory)?.title}
                </strong>
              </div>
              <p style={{ fontSize: 12, color: '#667781', marginBottom: 8 }}>
                These methods are available in the main chat interface. Open a chat and use the
                appropriate buttons and forms to access these features:
              </p>
              <ul style={{ fontSize: 12, marginBottom: 0, paddingLeft: 20 }}>
                {selectedCategory === 'account' && (
                  <>
                    <li>View account settings in Settings panel</li>
                    <li>Check instance status in sidebar</li>
                    <li>Manage instance from Settings</li>
                  </>
                )}
                {selectedCategory === 'sending' && (
                  <>
                    <li>Click attachment icon (📎) in chat footer</li>
                    <li>Select: File, Contact, Location, Poll, Template</li>
                    <li>Use sendLink for preview links</li>
                  </>
                )}
                {selectedCategory === 'groups' && (
                  <>
                    <li>Create groups from chat list</li>
                    <li>Open group chat for management</li>
                    <li>Add/remove participants, change settings</li>
                  </>
                )}
                {selectedCategory === 'service' && (
                  <>
                    <li>Archive/unarchive from chat menu</li>
                    <li>Check WhatsApp numbers before messaging</li>
                    <li>Set disappearing messages in chat settings</li>
                  </>
                )}
                {selectedCategory === 'journals' && (
                  <>
                    <li>Open any chat to see full history</li>
                    <li>Messages load automatically</li>
                    <li>Scroll up for older messages</li>
                  </>
                )}
                {selectedCategory === 'statuses' && (
                  <>
                    <li>Click Status button in chat footer</li>
                    <li>Create text, voice, or media statuses</li>
                    <li>View incoming/outgoing statuses</li>
                  </>
                )}
                {selectedCategory === 'queues' && (
                  <>
                    <li>Messages queue automatically</li>
                    <li>View queue status in developer tools</li>
                    <li>Clear queue if needed</li>
                  </>
                )}
                {selectedCategory === 'marks' && (
                  <>
                    <li>Chats marked as read automatically</li>
                    <li>Manual read marking available</li>
                    <li>Read receipts sent per chat settings</li>
                  </>
                )}
              </ul>
            </div>
            <div className="bubble-time">Just now</div>
          </div>
        )}

        <div className="message-bubble incoming" style={{ marginTop: 16 }}>
          <div className="bubble-content">
            <strong>💡 Pro Tip</strong>
            <p style={{ marginTop: 8, marginBottom: 0, fontSize: 13 }}>
              All WhatsApp features are integrated throughout the app. Navigate to Chats to start
              messaging, use the attachment menu for sending different content types, and access
              Settings for account management.
            </p>
          </div>
          <div className="bubble-time">Just now</div>
        </div>
      </div>
    </div>
  );
};

export default APITools;
