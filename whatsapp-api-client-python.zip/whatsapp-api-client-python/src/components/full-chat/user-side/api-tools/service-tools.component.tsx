import { FC } from 'react';
import { Button, Card, Input, Form, Space, message, Switch } from 'antd';
import { useAppSelector } from 'hooks';
import { selectInstance } from 'store/slices/instances.slice';
import { selectActiveChat } from 'store/slices/chat.slice';
import {
  useCheckWhatsappMutation,
  useArchiveChatMutation,
  useUnarchiveChatMutation,
  useSetDisappearingChatMutation,
  useSendTypingMutation,
  useGetContactsQuery,
} from 'services/green-api/endpoints';

const ServiceTools: FC = () => {
  const instance = useAppSelector(selectInstance);
  const activeChat = useAppSelector(selectActiveChat);
  const [checkWhatsapp, { isLoading: isChecking }] = useCheckWhatsappMutation();
  const [archiveChat, { isLoading: isArchiving }] = useArchiveChatMutation();
  const [unarchiveChat, { isLoading: isUnarchiving }] = useUnarchiveChatMutation();
  const [setDisappearingChat, { isLoading: isSettingDisappearing }] =
    useSetDisappearingChatMutation();
  const [sendTyping, { isLoading: isTyping }] = useSendTypingMutation();
  const { data: contacts, refetch: refetchContacts } = useGetContactsQuery(instance);

  const handleCheckWhatsapp = async (values: any) => {
    try {
      const result = await checkWhatsapp({
        ...instance,
        phoneNumber: values.phoneNumber,
      }).unwrap();
      message.success(`WhatsApp check: ${result.existsWhatsapp ? 'User exists' : 'No account'}`);
    } catch (error) {
      message.error('Failed to check WhatsApp');
    }
  };

  const handleArchive = async () => {
    if (!activeChat) {
      message.error('Please select a chat first');
      return;
    }
    try {
      await archiveChat({ ...instance, chatId: activeChat.chatId }).unwrap();
      message.success('Chat archived');
    } catch (error) {
      message.error('Failed to archive chat');
    }
  };

  const handleUnarchive = async () => {
    if (!activeChat) {
      message.error('Please select a chat first');
      return;
    }
    try {
      await unarchiveChat({ ...instance, chatId: activeChat.chatId }).unwrap();
      message.success('Chat unarchived');
    } catch (error) {
      message.error('Failed to unarchive chat');
    }
  };

  const handleDisappearing = async (values: any) => {
    if (!activeChat) {
      message.error('Please select a chat first');
      return;
    }
    try {
      await setDisappearingChat({
        ...instance,
        chatId: activeChat.chatId,
        ephemeralExpiration: values.enabled ? 86400 : 0,
      }).unwrap();
      message.success(`Disappearing messages ${values.enabled ? 'enabled' : 'disabled'}`);
    } catch (error) {
      message.error('Failed to set disappearing messages');
    }
  };

  const handleSendTyping = async () => {
    if (!activeChat) {
      message.error('Please select a chat first');
      return;
    }
    try {
      await sendTyping({ ...instance, chatId: activeChat.chatId }).unwrap();
      message.success('Typing indicator sent');
    } catch (error) {
      message.error('Failed to send typing');
    }
  };

  return (
    <div className="tool-section">
      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
        <Card title="Check WhatsApp" size="small">
          <Form onFinish={handleCheckWhatsapp} layout="vertical">
            <Form.Item name="phoneNumber" label="Phone Number" rules={[{ required: true }]}>
              <Input placeholder="79001234567" />
            </Form.Item>
            <Button type="primary" htmlType="submit" loading={isChecking}>
              Check WhatsApp
            </Button>
          </Form>
        </Card>

        <Card title="Chat Archive" size="small">
          <Space>
            <Button loading={isArchiving} onClick={handleArchive}>
              Archive Active Chat
            </Button>
            <Button loading={isUnarchiving} onClick={handleUnarchive}>
              Unarchive Active Chat
            </Button>
          </Space>
        </Card>

        <Card title="Disappearing Messages" size="small">
          <Form onFinish={handleDisappearing} layout="vertical">
            <Form.Item name="enabled" label="Enable disappearing messages" valuePropName="checked">
              <Switch />
            </Form.Item>
            <Button type="primary" htmlType="submit" loading={isSettingDisappearing}>
              Set Disappearing Messages
            </Button>
          </Form>
        </Card>

        <Card title="Typing Indicator" size="small">
          <Button loading={isTyping} onClick={handleSendTyping}>
            Send Typing Indicator
          </Button>
        </Card>

        <Card title="Get All Contacts" size="small">
          <Button onClick={() => refetchContacts()}>Fetch Contacts</Button>
          {contacts && (
            <pre style={{ marginTop: 10, fontSize: 12, maxHeight: 200, overflow: 'auto' }}>
              {JSON.stringify(contacts, null, 2)}
            </pre>
          )}
        </Card>
      </Space>
    </div>
  );
};

export default ServiceTools;
