import { FC } from 'react';
import { Button, Card, Space, InputNumber, Form } from 'antd';
import { useAppSelector } from 'hooks';
import { selectInstance } from 'store/slices/instances.slice';

const JournalTools: FC = () => {
  const instance = useAppSelector(selectInstance);

  return (
    <div className="tool-section">
      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
        <Card title="Message Journals" size="small">
          <p style={{ fontSize: 12, color: '#8c8c8c' }}>
            Message history and journals are already available in the chat interface. Use the chat
            view to see getChatHistory, lastMessages, lastIncomingMessages, and
            lastOutgoingMessages.
          </p>
        </Card>
      </Space>
    </div>
  );
};

export default JournalTools;
