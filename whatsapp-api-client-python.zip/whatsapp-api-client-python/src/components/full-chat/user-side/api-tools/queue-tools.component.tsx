import { FC } from 'react';
import { Button, Card, Space, message } from 'antd';
import { useAppSelector } from 'hooks';
import { selectInstance } from 'store/slices/instances.slice';
import {
  useShowMessagesQueueQuery,
  useClearMessagesQueueMutation,
} from 'services/green-api/endpoints';

const QueueTools: FC = () => {
  const instance = useAppSelector(selectInstance);
  const { data: messagesQueue, refetch: refetchQueue } = useShowMessagesQueueQuery(instance);
  const [clearQueue, { isLoading: isClearing }] = useClearMessagesQueueMutation();

  const handleClearQueue = async () => {
    try {
      await clearQueue(instance).unwrap();
      message.success('Messages queue cleared');
      refetchQueue();
    } catch (error) {
      message.error('Failed to clear queue');
    }
  };

  return (
    <div className="tool-section">
      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
        <Card title="Messages Queue" size="small">
          <Space>
            <Button onClick={() => refetchQueue()}>Show Messages Queue</Button>
            <Button danger loading={isClearing} onClick={handleClearQueue}>
              Clear Messages Queue
            </Button>
          </Space>
          {messagesQueue && (
            <pre style={{ marginTop: 10, fontSize: 12, maxHeight: 400, overflow: 'auto' }}>
              {JSON.stringify(messagesQueue, null, 2)}
            </pre>
          )}
        </Card>
      </Space>
    </div>
  );
};

export default QueueTools;
