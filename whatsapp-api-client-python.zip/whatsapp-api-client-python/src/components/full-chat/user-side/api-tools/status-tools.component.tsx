import { FC } from 'react';
import { Button, Card, Space, InputNumber, Form } from 'antd';
import { useAppSelector } from 'hooks';
import { selectInstance } from 'store/slices/instances.slice';
import {
  useGetIncomingStatusesQuery,
  useGetOutgoingStatusesQuery,
} from 'services/green-api/endpoints';

const StatusTools: FC = () => {
  const instance = useAppSelector(selectInstance);
  const { data: incomingStatuses, refetch: refetchIncoming } = useGetIncomingStatusesQuery({
    ...instance,
    minutes: 1440,
  });
  const { data: outgoingStatuses, refetch: refetchOutgoing } = useGetOutgoingStatusesQuery({
    ...instance,
    minutes: 1440,
  });

  return (
    <div className="tool-section">
      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
        <Card title="Incoming Statuses" size="small">
          <Button onClick={() => refetchIncoming()}>Get Incoming Statuses (24h)</Button>
          {incomingStatuses && (
            <pre style={{ marginTop: 10, fontSize: 12, maxHeight: 300, overflow: 'auto' }}>
              {JSON.stringify(incomingStatuses, null, 2)}
            </pre>
          )}
        </Card>

        <Card title="Outgoing Statuses" size="small">
          <Button onClick={() => refetchOutgoing()}>Get Outgoing Statuses (24h)</Button>
          {outgoingStatuses && (
            <pre style={{ marginTop: 10, fontSize: 12, maxHeight: 300, overflow: 'auto' }}>
              {JSON.stringify(outgoingStatuses, null, 2)}
            </pre>
          )}
        </Card>

        <Card title="Status Actions" size="small">
          <p style={{ fontSize: 12, color: '#8c8c8c' }}>
            Create and manage WhatsApp statuses (stories) using the Status button in the chat
            footer. This includes sendTextStatus, sendVoiceStatus, sendMediaStatus, and
            deleteStatus methods.
          </p>
        </Card>
      </Space>
    </div>
  );
};

export default StatusTools;
