import { FC } from 'react';
import { Button, Card, Input, Form, Space, message } from 'antd';
import { useAppSelector } from 'hooks';
import { selectInstance } from 'store/slices/instances.slice';
import { useCreateGroupMutation } from 'services/green-api/endpoints';

const GroupTools: FC = () => {
  const instance = useAppSelector(selectInstance);
  const [createGroup, { isLoading }] = useCreateGroupMutation();

  const handleCreateGroup = async (values: any) => {
    try {
      const chatIds = values.chatIds.split(',').map((id: string) => id.trim());
      await createGroup({
        ...instance,
        groupName: values.groupName,
        chatIds,
      }).unwrap();
      message.success('Group created successfully');
    } catch (error) {
      message.error('Failed to create group');
    }
  };

  return (
    <div className="tool-section">
      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
        <Card title="Create Group" size="small">
          <Form onFinish={handleCreateGroup} layout="vertical">
            <Form.Item name="groupName" label="Group Name" rules={[{ required: true }]}>
              <Input placeholder="My WhatsApp Group" />
            </Form.Item>
            <Form.Item
              name="chatIds"
              label="Participant Chat IDs (comma separated)"
              rules={[{ required: true }]}
            >
              <Input placeholder="79001234567@c.us, 79007654321@c.us" />
            </Form.Item>
            <Button type="primary" htmlType="submit" loading={isLoading}>
              Create Group
            </Button>
          </Form>
        </Card>

        <Card title="Other Group Actions" size="small">
          <p style={{ fontSize: 12, color: '#8c8c8c' }}>
            Additional group management features are available in the group chat interface: update
            group name, add/remove participants, set admins, upload group picture, etc.
          </p>
        </Card>
      </Space>
    </div>
  );
};

export default GroupTools;
