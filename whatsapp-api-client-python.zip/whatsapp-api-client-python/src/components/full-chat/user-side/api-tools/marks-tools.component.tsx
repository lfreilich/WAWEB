import { FC } from 'react';
import { Button, Card, Space, message } from 'antd';
import { useAppSelector } from 'hooks';
import { selectInstance } from 'store/slices/instances.slice';
import { selectActiveChat } from 'store/slices/chat.slice';
import { useReadChatMutation } from 'services/green-api/endpoints';

const MarksTools: FC = () => {
  const instance = useAppSelector(selectInstance);
  const activeChat = useAppSelector(selectActiveChat);
  const [readChat, { isLoading }] = useReadChatMutation();

  const handleReadChat = async () => {
    if (!activeChat) {
      message.error('Please select a chat first');
      return;
    }
    try {
      await readChat({
        ...instance,
        chatId: activeChat.chatId,
      }).unwrap();
      message.success('Chat marked as read');
    } catch (error) {
      message.error('Failed to mark chat as read');
    }
  };

  return (
    <div className="tool-section">
      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
        <Card title="Read Chat" size="small">
          <p style={{ fontSize: 12, color: '#8c8c8c' }}>
            Mark the currently active chat as read. This sends read receipts for all messages in
            the chat.
          </p>
          <Button loading={isLoading} onClick={handleReadChat} type="primary">
            Mark Active Chat as Read
          </Button>
        </Card>
      </Space>
    </div>
  );
};

export default MarksTools;
