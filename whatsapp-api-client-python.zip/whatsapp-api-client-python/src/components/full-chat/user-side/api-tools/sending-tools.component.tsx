import { FC, useState } from 'react';
import { Button, Card, Input, Form, Space, message } from 'antd';
import { useAppSelector } from 'hooks';
import { selectInstance } from 'store/slices/instances.slice';
import { selectActiveChat } from 'store/slices/chat.slice';
import {
  useSendFileByUrlMutation,
  useForwardMessagesMutation,
  useSendLinkMutation,
} from 'services/green-api/endpoints';

const { TextArea } = Input;

const SendingTools: FC = () => {
  const instance = useAppSelector(selectInstance);
  const activeChat = useAppSelector(selectActiveChat);
  const [sendFileByUrl, { isLoading: isSendingFile }] = useSendFileByUrlMutation();
  const [forwardMessages, { isLoading: isForwarding }] = useForwardMessagesMutation();
  const [sendLink, { isLoading: isSendingLink }] = useSendLinkMutation();

  const handleSendFileByUrl = async (values: any) => {
    if (!activeChat) {
      message.error('Please select a chat first');
      return;
    }
    try {
      await sendFileByUrl({
        ...instance,
        chatId: activeChat.chatId,
        ...values,
      }).unwrap();
      message.success('File sent successfully');
    } catch (error) {
      message.error('Failed to send file');
    }
  };

  const handleSendLink = async (values: any) => {
    if (!activeChat) {
      message.error('Please select a chat first');
      return;
    }
    try {
      await sendLink({
        ...instance,
        chatId: activeChat.chatId,
        ...values,
      }).unwrap();
      message.success('Link sent successfully');
    } catch (error) {
      message.error('Failed to send link');
    }
  };

  return (
    <div className="tool-section">
      <Space direction="vertical" size="middle" style={{ width: '100%' }}>
        <Card title="Send File by URL" size="small">
          <Form onFinish={handleSendFileByUrl} layout="vertical">
            <Form.Item name="urlFile" label="File URL" rules={[{ required: true }]}>
              <Input placeholder="https://example.com/file.pdf" />
            </Form.Item>
            <Form.Item name="fileName" label="File Name">
              <Input placeholder="document.pdf" />
            </Form.Item>
            <Form.Item name="caption" label="Caption">
              <TextArea placeholder="Optional caption" />
            </Form.Item>
            <Button type="primary" htmlType="submit" loading={isSendingFile}>
              Send File
            </Button>
          </Form>
        </Card>

        <Card title="Send Link" size="small">
          <Form onFinish={handleSendLink} layout="vertical">
            <Form.Item name="urlLink" label="Link URL" rules={[{ required: true }]}>
              <Input placeholder="https://example.com" />
            </Form.Item>
            <Button type="primary" htmlType="submit" loading={isSendingLink}>
              Send Link
            </Button>
          </Form>
        </Card>

        <Card title="Forward Messages" size="small">
          <p style={{ fontSize: 12, color: '#8c8c8c' }}>
            Forward messages from one chat to another. Requires message IDs.
          </p>
          <Button disabled>Coming Soon</Button>
        </Card>
      </Space>
    </div>
  );
};

export default SendingTools;
