import { CommentOutlined, SettingOutlined, ContactsOutlined, ApiOutlined } from '@ant-design/icons';

import Chats from 'components/full-chat/user-side/chats/chats.component';
import Settings from 'components/full-chat/user-side/settings/settings.component';
import Phonebook from 'components/full-chat/user-side/phonebook/phonebook.component';
import APITools from 'components/full-chat/user-side/api-tools/api-tools.component';
import { AsideItem, UserSideItem } from 'types';

export const asideTopIconItems: AsideItem[] = [
  { item: 'chats', title: 'CHATS_TITLE', icon: <CommentOutlined /> },
  { item: 'phonebook', title: 'PHONEBOOK_TITLE', icon: <ContactsOutlined /> },
  { item: 'api-tools', title: 'API_TOOLS_TITLE', icon: <ApiOutlined /> },
];

export const asideBottomIconItems: AsideItem[] = [
  { item: 'profile', title: 'PROFILE_TITLE', icon: <SettingOutlined /> },
];

export const USER_SIDE_ITEMS: UserSideItem[] = [
  { item: 'chats', element: <Chats /> },
  { item: 'settings', element: <Settings /> },
  { item: 'phonebook', element: <Phonebook /> },
  { item: 'api-tools', element: <APITools /> },
];
