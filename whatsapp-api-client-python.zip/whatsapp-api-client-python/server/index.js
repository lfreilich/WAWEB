import express from 'express';
import cors from 'cors';
import pkg from 'pg';
const { Pool } = pkg;

const app = express();
const port = 3000;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

app.use(cors());
app.use(express.json());

app.get('/api/contacts', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM contacts ORDER BY name ASC'
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching contacts:', error);
    res.status(500).json({ error: 'Failed to fetch contacts' });
  }
});

app.get('/api/contacts/:chatId', async (req, res) => {
  try {
    const { chatId } = req.params;
    const result = await pool.query(
      'SELECT * FROM contacts WHERE chat_id = $1',
      [chatId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Contact not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching contact:', error);
    res.status(500).json({ error: 'Failed to fetch contact' });
  }
});

app.post('/api/contacts', async (req, res) => {
  try {
    const { chat_id, name, phone_number, avatar_url, notes, is_favorite } = req.body;
    const result = await pool.query(
      'INSERT INTO contacts (chat_id, name, phone_number, avatar_url, notes, is_favorite) VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT (chat_id) DO UPDATE SET name = $2, phone_number = $3, avatar_url = $4, notes = $5, is_favorite = $6, updated_at = CURRENT_TIMESTAMP RETURNING *',
      [chat_id, name, phone_number, avatar_url, notes, is_favorite || false]
    );
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error creating/updating contact:', error);
    res.status(500).json({ error: 'Failed to create/update contact' });
  }
});

app.put('/api/contacts/:chatId', async (req, res) => {
  try {
    const { chatId } = req.params;
    const { name, phone_number, avatar_url, notes, is_favorite } = req.body;
    const result = await pool.query(
      'UPDATE contacts SET name = $1, phone_number = $2, avatar_url = $3, notes = $4, is_favorite = $5, updated_at = CURRENT_TIMESTAMP WHERE chat_id = $6 RETURNING *',
      [name, phone_number, avatar_url, notes, is_favorite, chatId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Contact not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating contact:', error);
    res.status(500).json({ error: 'Failed to update contact' });
  }
});

app.delete('/api/contacts/:chatId', async (req, res) => {
  try {
    const { chatId } = req.params;
    await pool.query('DELETE FROM contacts WHERE chat_id = $1', [chatId]);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting contact:', error);
    res.status(500).json({ error: 'Failed to delete contact' });
  }
});

app.get('/api/messages/:chatId', async (req, res) => {
  try {
    const { chatId } = req.params;
    const { limit = 50, offset = 0 } = req.query;
    const result = await pool.query(
      'SELECT * FROM messages WHERE chat_id = $1 ORDER BY timestamp DESC LIMIT $2 OFFSET $3',
      [chatId, limit, offset]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

app.post('/api/messages', async (req, res) => {
  try {
    const { message_id, chat_id, sender_name, message_type, text_message, file_url, timestamp, is_incoming, status, quoted_message_id } = req.body;
    
    await pool.query(
      'INSERT INTO contacts (chat_id, name) VALUES ($1, $2) ON CONFLICT (chat_id) DO NOTHING',
      [chat_id, sender_name]
    );
    
    const result = await pool.query(
      'INSERT INTO messages (message_id, chat_id, sender_name, message_type, text_message, file_url, timestamp, is_incoming, status, quoted_message_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) ON CONFLICT (message_id) DO UPDATE SET status = $9 RETURNING *',
      [message_id, chat_id, sender_name, message_type, text_message, file_url, timestamp, is_incoming, status, quoted_message_id]
    );
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error saving message:', error);
    res.status(500).json({ error: 'Failed to save message' });
  }
});

app.delete('/api/messages/:chatId', async (req, res) => {
  try {
    const { chatId } = req.params;
    const result = await pool.query(
      'DELETE FROM messages WHERE chat_id = $1',
      [chatId]
    );
    res.json({ success: true, deletedCount: result.rowCount });
  } catch (error) {
    console.error('Error clearing messages:', error);
    res.status(500).json({ error: 'Failed to clear messages' });
  }
});

app.get('/api/search', async (req, res) => {
  try {
    const { q } = req.query;
    const result = await pool.query(
      'SELECT * FROM contacts WHERE name ILIKE $1 OR phone_number ILIKE $1 OR notes ILIKE $1 LIMIT 20',
      [`%${q}%`]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error searching contacts:', error);
    res.status(500).json({ error: 'Failed to search contacts' });
  }
});

app.post('/webhook/green-api', async (req, res) => {
  try {
    const webhook = req.body;
    console.log('Received webhook:', JSON.stringify(webhook, null, 2));
    
    const { typeWebhook, instanceData, timestamp } = webhook;
    
    if (typeWebhook === 'incomingMessageReceived') {
      const { messageData, senderData } = webhook;
      const chatId = messageData?.chatId || senderData?.chatId;
      const messageId = messageData?.idMessage;
      const textMessage = messageData?.textMessageData?.textMessage || '';
      const messageType = messageData?.typeMessage || 'textMessage';
      const senderName = senderData?.senderName || senderData?.sender || '';
      
      if (chatId && messageId) {
        await pool.query(
          'INSERT INTO contacts (chat_id, name) VALUES ($1, $2) ON CONFLICT (chat_id) DO UPDATE SET name = $2, updated_at = CURRENT_TIMESTAMP',
          [chatId, senderName]
        );
        
        await pool.query(
          'INSERT INTO messages (message_id, chat_id, sender_name, message_type, text_message, timestamp, is_incoming, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) ON CONFLICT (message_id) DO NOTHING',
          [messageId, chatId, senderName, messageType, textMessage, timestamp, true, 'delivered']
        );
      }
    } else if (typeWebhook === 'outgoingMessageStatus') {
      const { messageData, statusData } = webhook;
      const messageId = messageData?.idMessage;
      const status = statusData?.status || 'sent';
      
      if (messageId) {
        await pool.query(
          'UPDATE messages SET status = $1 WHERE message_id = $2',
          [status, messageId]
        );
      }
    }
    
    res.status(200).json({ success: true });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(200).json({ success: false, error: error.message });
  }
});

app.get('/api/sync/contacts', async (req, res) => {
  try {
    const instanceId = process.env.GREEN_API_INSTANCE_ID || '7105277440';
    const apiToken = process.env.GREEN_API_TOKEN;
    
    if (!apiToken) {
      return res.status(500).json({ error: 'GREEN API credentials not configured' });
    }

    const greenApiUrl = `https://7105.api.greenapi.com/waInstance${instanceId}/getContacts/${apiToken}`;
    const response = await fetch(greenApiUrl);
    
    if (!response.ok) {
      return res.status(500).json({ error: 'Failed to fetch contacts from WhatsApp' });
    }

    const whatsappContacts = await response.json();
    let savedCount = 0;

    for (const contact of whatsappContacts) {
      const chatId = contact.id || contact.chatId;
      const name = contact.name || contact.pushname || chatId;
      
      await pool.query(
        'INSERT INTO contacts (chat_id, name, phone_number) VALUES ($1, $2, $3) ON CONFLICT (chat_id) DO UPDATE SET name = $2, phone_number = $3, updated_at = CURRENT_TIMESTAMP',
        [chatId, name, chatId.replace('@c.us', '')]
      );
      savedCount++;
    }

    res.json({ success: true, count: savedCount });
  } catch (error) {
    console.error('Error syncing contacts:', error);
    res.status(500).json({ error: 'Failed to sync contacts' });
  }
});

app.get('/api/sync/chats', async (req, res) => {
  try {
    const instanceId = process.env.GREEN_API_INSTANCE_ID || '7105277440';
    const apiToken = process.env.GREEN_API_TOKEN;
    
    if (!apiToken) {
      return res.status(500).json({ error: 'GREEN API credentials not configured' });
    }

    const greenApiUrl = `https://7105.api.greenapi.com/waInstance${instanceId}/getChats/${apiToken}`;
    const response = await fetch(greenApiUrl);
    
    if (!response.ok) {
      return res.status(500).json({ error: 'Failed to fetch chats from WhatsApp' });
    }

    const chats = await response.json();
    let savedCount = 0;

    for (const chat of chats) {
      const chatId = chat.id;
      const name = chat.name || chatId;
      
      await pool.query(
        'INSERT INTO contacts (chat_id, name) VALUES ($1, $2) ON CONFLICT (chat_id) DO UPDATE SET name = $2, updated_at = CURRENT_TIMESTAMP',
        [chatId, name]
      );
      savedCount++;
    }

    res.json({ success: true, count: savedCount });
  } catch (error) {
    console.error('Error syncing chats:', error);
    res.status(500).json({ error: 'Failed to sync chats' });
  }
});

app.get('/webhook/green-api', (req, res) => {
  res.json({ 
    status: 'Webhook endpoint is active',
    timestamp: new Date().toISOString(),
    instanceId: process.env.GREEN_API_INSTANCE_ID || 'Not configured'
  });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
  console.log(`Webhook URL: https://${process.env.REPLIT_DEV_DOMAIN.replace('-00-', '-00-3000-')}/webhook/green-api`);
});
