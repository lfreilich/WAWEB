# Green API Chat

A React/TypeScript chat application for WhatsApp integration using the GREEN API service.

## Project Overview
- **Type**: React + TypeScript + Vite web application
- **Purpose**: Chat module for personal WhatsApp accounts using GREEN-API
- **Framework**: React 18 with Vite build tool
- **UI Library**: Ant Design (antd)
- **State Management**: Redux Toolkit
- **Internationalization**: i18next
- **Styling**: SASS/SCSS

## Project Structure
- `/src` - Source code (components, redux, i18n, etc.)
- `/public` - Static assets
- `vite.config.ts` - Vite configuration (configured for Replit)
- `package.json` - Dependencies and scripts

## Configuration
The app has been configured for Replit environment:
- Dev server runs on port 5000
- Host set to 0.0.0.0 for external access
- HMR configured for Replit's proxy

## Development
- **Start dev server**: `npm run dev` (configured in workflow)
- **Build**: `npm run build`
- **Preview production**: `npm run preview`

## Authorization
The app requires GREEN API credentials which can be provided via:
1. URL query parameters: `?idInstance=XXX&apiTokenInstance=YYY&apiUrl=...&mediaUrl=...`
2. postMessage API from parent window (for iframe embedding)

See README.md for detailed authorization instructions.

## GREEN API Integration
The application now supports **ALL** available GREEN API endpoints from the complete API documentation, organized by category:

### Account Management (Complete)
- `getWaSettings` - Get WhatsApp account settings
- `getAccountSettings` - Get instance settings
- `setSettings` - Update instance settings
- `getStateInstance` - Get instance state
- `getStatusInstance` - Get instance connection status
- `reboot` - Reboot instance
- `logout` - Logout instance
- `qr` - Get QR code for authorization
- `setProfilePicture` - Set account avatar
- `getAuthorizationCode` - Phone number authorization
- `getDeviceInfo` - Get device information
- `updateAPIToken` - Update API token
- `getWhatsAppAccountInformation` - Get WhatsApp account info

### Sending Messages
- `sendMessage` - Send text messages
- `sendFileByUpload` - Send files by uploading
- `sendFileByUrl` - Send files by URL
- `sendContact` - Send contact cards
- `sendLocation` - Send location
- `sendPoll` - Send polls
- `sendLink` - Send link with preview
- `forwardMessages` - Forward messages
- `sendInteractiveButtons` - Send interactive buttons
- `sendInteractiveButtonsReply` - Reply to interactive buttons

### Receiving Messages
- `receiveNotification` - Receive incoming notifications
- `deleteNotification` - Delete notifications

### Message Journals
- `getChatHistory` - Get chat message history
- `lastIncomingMessages` - Get last incoming messages
- `lastOutgoingMessages` - Get last outgoing messages
- `lastMessages` - Get all recent messages

### Groups Management
- `createGroup` - Create new group
- `getGroupData` - Get group information
- `updateGroupName` - Update group name
- `updateGroupSettings` - Update group settings
- `addGroupParticipant` - Add participants
- `removeParticipant` - Remove participants
- `setGroupAdmin` - Set admin rights
- `removeAdmin` - Remove admin rights
- `setGroupPicture` - Set group avatar
- `leaveGroup` - Leave group

### Statuses (WhatsApp Stories)
- `sendTextStatus` - Send text status
- `sendVoiceStatus` - Send voice status
- `sendMediaStatus` - Send media status
- `deleteStatus` - Delete status
- `getStatusStatistic` - Get status statistics
- `getIncomingStatuses` - Get incoming statuses
- `getOutgoingStatuses` - Get outgoing statuses

### Service Methods
- `checkWhatsapp` - Check WhatsApp availability
- `getAvatar` - Get contact/group avatar
- `getContactInfo` - Get contact information
- `getContacts` - Get all contacts
- `deleteMessage` - Delete messages
- `editMessage` - Edit messages
- `uploadFile` - Upload files to cloud
- `archiveChat` - Archive chat
- `unarchiveChat` - Unarchive chat
- `setDisappearingChat` - Set disappearing messages
- `sendTyping` - Send typing indicator

### Message Queues (Complete)
- `showMessagesQueue` - View message queue
- `clearMessagesQueue` - Clear message queue
- `getMessagesCount` - Get messages count to send
- `getWebhooksCount` - Get webhooks count in queue
- `clearIncomingWebhooksQueue` - Clear incoming webhooks queue

### Read Marks (Complete)
- `readChat` - Mark chat as read
- `markMessageAsRead` - Mark specific message as read

### Receiving (Complete)
- `receiveNotification` - Receive incoming notifications
- `deleteNotification` - Delete notifications
- `downloadFile` - Download file from incoming message

### Journals (Complete)
- `getChatHistory` - Get chat message history
- `getChatMessage` - Get specific chat message
- `lastIncomingMessages` - Get last incoming messages
- `lastOutgoingMessages` - Get last outgoing messages
- `lastMessages` - Get all recent messages

### WABA Templates
- `getTemplates` - Get WhatsApp Business templates
- `getTemplateById` - Get specific template
- `sendTemplate` - Send template message

## Database & Backend
- **PostgreSQL Database**: Configured with two main tables:
  - `contacts` - Store contact information with favorites support
  - `messages` - Store message history with full metadata
- **Express Backend API** (port 3000): REST API for database operations
  - Endpoints: `/api/contacts`, `/api/messages`, `/api/search`
  - CRUD operations for contacts and messages
  - Automatic contact creation from messages

## New Features
### Phonebook
- Full contact management system in sidebar
- Add, edit, delete contacts
- Favorite contacts with star functionality
- Search contacts by name, phone, or notes
- Integrated with database for persistence

### API Tools Guide
- WhatsApp-style chat interface
- Interactive guide to all GREEN API features
- 8 categories covering all 60+ API methods
- Shows where to find each feature in the app
- Beautiful WhatsApp-themed design with message bubbles

## Recent Changes
- October 4, 2025: Message Management & Header Visibility Fixes
  - Added chat management menu (⋮) in contact chat header with:
    - Archive Chat - Move conversations to archive
    - Unarchive Chat - Restore from archive
    - Clear All Messages - Delete all messages with confirmation
  - Fixed header text visibility issues across all headers
  - Applied WhatsApp green (#008069) to chats header with white icons
  - Added comprehensive header styling for contact-chat-header and contact-info-header
  - Backend endpoint: DELETE /api/messages/:chatId for clearing messages
  - All message management features integrated and working
- October 4, 2025: WhatsApp Web UI Enhancements
  - Updated chat list styling: 50px circular avatars, improved spacing
  - Enhanced font weights: 500 for names, 400 for messages
  - Added proper timestamps (12px, right-aligned)
  - Improved search bar with rounded corners and better padding
  - Fixed hover states (#f5f6f6) and active chat highlighting
  - WhatsApp-style header with green background and white icons
- October 3, 2025: Complete WhatsApp Web UI transformation
  - Removed ALL visible GREEN-API branding (logo, text mentions)
  - Replaced home view with WhatsApp-style empty state
  - Applied authentic WhatsApp Web color scheme (#f0f2f5 backgrounds, #d1d7db borders)
  - Updated ChatsHeader to use WhatsApp-style avatar and icons
  - Created WhatsApp search bar styling (rounded gray input)
  - Added WhatsApp chat list item styling (hover effects, proper spacing)
  - Updated API Tools to remove GREEN-API branding ("WhatsApp API Assistant")
  - Note: Home view text is now English-only (i18n removed with branding)
- October 3, 2025: Complete WhatsApp-style UI transformation
  - Applied authentic WhatsApp color scheme (#00a884 green, #e5ddd5 beige background)
  - Added WhatsApp patterned chat background with diagonal lines
  - Styled message bubbles with tails (white incoming, green outgoing)
  - Updated both light and dark themes to match WhatsApp
  - Enhanced chat headers and overall layout with WhatsApp aesthetics
- October 3, 2025: Complete database integration and UI enhancements
  - Set up PostgreSQL with contacts and messages tables
  - Created Express backend API on port 3000
  - Added Phonebook feature with full CRUD operations
  - Created WhatsApp-style API Tools guide interface
  - Configured API URL handling for Replit environment
  - All features tested and working
- October 3, 2025: Initial setup and complete GREEN API configuration
  - Configured Vite for port 5000 and Replit proxy
  - Installed all dependencies
  - Set up dev server workflow
  - Added all GREEN API endpoints from official documentation
  - Created new endpoint modules: queues, marks
  - Extended account, sending, service, group, and statuses endpoints
  - All 60+ API methods now available via React hooks
  - Application locked to instance ID 7105277440
