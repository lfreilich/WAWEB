import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import svgr from 'vite-plugin-svgr';
import tsconfigPaths from 'vite-tsconfig-paths';

declare const process: any;

const assetsDirectory = 'assets_0.0.65';
const hash = Math.floor(Math.random() * 90_000) + 10_000;

// https://vitejs.dev/config/
export default defineConfig({
  build: {
    assetsDir: assetsDirectory,
    rollupOptions: {
      output: {
        entryFileNames: `${assetsDirectory}/[name].${hash}.js`,
        chunkFileNames: `${assetsDirectory}/[name].${hash}.js`,
        assetFileNames: `${assetsDirectory}/[name].${hash}.[ext]`,
      },
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5000,
    hmr: {
      clientPort: 443,
    },
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
      },
    },
  },
  define: {
    'import.meta.env.VITE_GREEN_API_INSTANCE_ID': JSON.stringify(process.env.GREEN_API_INSTANCE_ID),
    'import.meta.env.VITE_GREEN_API_TOKEN': JSON.stringify(process.env.GREEN_API_TOKEN),
  },
  plugins: [svgr(), react(), tsconfigPaths()],
});
